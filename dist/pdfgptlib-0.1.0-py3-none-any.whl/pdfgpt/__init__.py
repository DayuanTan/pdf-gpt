"""Top-level package for pdf gpt lib. This file tells Python that pdfgpt is a package."""


from .pdfgpt import *